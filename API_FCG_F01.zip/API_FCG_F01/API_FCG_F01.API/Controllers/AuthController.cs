using API_FCG_F01.Application.DTOs;
using API_FCG_F01.Application.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace API_FCG_F01.API.Controllers;

/// <summary>
/// Controller respons�vel pela autentica��o e registro de usu�rios
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AuthService _authService;

    public AuthController(AuthService authService)
    {
        _authService = authService;
    }

    /// <summary>
    /// Realiza o login do usu�rio
    /// </summary>
    /// <param name="login">Dados de login do usu�rio</param>
    /// <param name="ct">Token de cancelamento</param>
    /// <returns>Token de autentica��o e informa��es do usu�rio</returns>
    /// <response code="200">Login realizado com sucesso</response>
    /// <response code="401">Email ou senha inv�lidos</response>
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginDto login, CancellationToken ct)
    {
        try
        {
            var response = await _authService.LoginAsync(login, ct);
            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            return Unauthorized(new { message = ex.Message });
        }
    }

    /// <summary>
    /// Registra um novo usu�rio no sistema
    /// </summary>
    /// <param name="register">Dados do novo usu�rio</param>
    /// <param name="ct">Token de cancelamento</param>
    /// <returns>Token de autentica��o e informa��es do usu�rio</returns>
    /// <response code="200">Usu�rio registrado com sucesso</response>
    /// <response code="400">Email j� cadastrado ou dados inv�lidos</response>
    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Register([FromBody] RegisterDto register, CancellationToken ct)
    {
        try
        {
            var response = await _authService.RegisterAsync(register, ct);
            return Ok(response);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
}
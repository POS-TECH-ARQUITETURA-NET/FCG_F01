using API_FCG_F01.Domain.Entities;
using FluentAssertions;
using Xunit;

namespace API_FCG_F01.Tests
{
    public class UsuarioTests
    {
        // Teste 1: Deve falhar ao criar usu�rio com nome nulo
        [Fact(DisplayName = "Criar Usu�rio Com Nome Nulo Deve Lan�ar Exce��o")]
        public void CriarUsuario_ComNomeNulo_DeveLancarExcecao()
        {
            // Arrange & Act
            Action action = () => new Usuario(null, "email@teste.com", "senhaHash123", false);

            // Assert
            action.Should().Throw<ArgumentNullException>()
                         .WithMessage("Value cannot be null. (Parameter 'nome')");
        }

        // Teste 2: Deve falhar ao tentar alterar email para um formato inv�lido (refatora��o)
        [Theory(DisplayName = "Alterar Email Com Formato Inv�lido Deve Lan�ar Exce��o")]
        [InlineData("emailinvalido")]
        [InlineData("@.com")]
        [InlineData("teste@")]
        public void AlterarEmail_ComFormatoInvalido_DeveLancarExcecao(string emailInvalido)
        {
            // Arrange
            var usuario = new Usuario("Teste", "email@valido.com", "senhaHash123", false);

            // Act
            Action action = () => usuario.AlterarEmail(emailInvalido);

            // Assert
            action.Should().Throw<ArgumentException>()
                         .WithMessage("Formato de email inv�lido");
        }

        // Teste 3: Deve passar ao criar usu�rio com dados v�lidos
        [Fact(DisplayName = "Criar Usu�rio Com Dados V�lidos Deve Ser Bem Sucedido")]
        public void CriarUsuario_ComDadosValidos_DeveSerBemSucedido()
        {
            // Arrange
            string nome = "Usuario Teste";
            string email = "teste@email.com";
            string senhaHash = "senhaHash123";
            bool isAdmin = false;

            // Act
            var usuario = new Usuario(nome, email, senhaHash, isAdmin);

            // Assert
            usuario.Should().NotBeNull();
            usuario.Nome.Should().Be(nome);
            usuario.Email.Should().Be(email);
            usuario.Senha.Should().Be(senhaHash);
            usuario.IsAdministrador.Should().Be(isAdmin);
            usuario.Ativo.Should().BeTrue();
        }

        // Teste 4: Deve passar ao desativar e reativar usu�rio
        [Fact(DisplayName = "Desativar E Reativar Usu�rio Deve Funcionar Corretamente")]
        public void DesativarEReativar_Usuario_DeveAlterarEstadoCorretamente()
        {
            // Arrange
            var usuario = new Usuario("Teste", "email@teste.com", "senhaHash123", false);

            // Act & Assert
            usuario.Ativo.Should().BeTrue(); // Estado inicial

            usuario.Desativar();
            usuario.Ativo.Should().BeFalse(); // Ap�s desativa��o

            usuario.Ativar();
            usuario.Ativo.Should().BeTrue(); // Ap�s reativa��o
        }
    }
}
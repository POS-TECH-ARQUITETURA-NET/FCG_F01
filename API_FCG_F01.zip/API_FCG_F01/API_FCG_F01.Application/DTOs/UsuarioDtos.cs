namespace API_FCG_F01.Application.DTOs;

/// <summary>
/// DTO para cria��o de um novo usu�rio.
/// </summary>
/// <param name="Nome"></param>
/// <param name="Email"></param>
/// <param name="Senha"></param>
/// <param name="IsAdministrador"></param>
public sealed record UsuarioCreateDto(string Nome, string? Email, string Senha, bool IsAdministrador);

/// <summary>
/// DTO para atualiza��o de um usu�rio existente.
/// </summary>
/// <param name="Id"></param>
/// <param name="Nome"></param>
/// <param name="Email"></param>
/// <param name="Senha"></param>
/// <param name="IsAdministrador"></param>
/// <param name="Ativo"></param>
public sealed record UsuarioUpdateDto(Guid Id, string Nome, string? Email, string Senha, bool IsAdministrador, bool Ativo);

/// <summary>
/// DTO que representa um usu�rio.
/// </summary>
/// <param name="Id"></param>
/// <param name="Nome"></param>
/// <param name="Email"></param>
/// <param name="IsAdministrador"></param>
/// <param name="Ativo"></param>
/// <param name="DataCriacao"></param>
public sealed record UsuarioDto(Guid Id, string Nome, string? Email, bool IsAdministrador, bool Ativo, DateTimeOffset DataCriacao);
